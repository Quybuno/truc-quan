# Mã LaTeX tiểu luận

## Nội dung hiện tại

- `main.tex`: khung biên dịch của tiểu luận; hiện chỉ nạp Chương 1 và tài liệu tham khảo.
- `chuong/chuong1.tex`: nội dung hoàn chỉnh Chương 1 theo đề cương lý thuyết–thực hành.
- `tailieu-thamkhao.tex`: các nguồn được dẫn trong Chương 1.

Bìa, thông tin sinh viên, tóm tắt, mục lục và các chương còn lại sẽ thêm khi viết tiếp. Tệp này không tự điền tên sinh viên hoặc giảng viên.

## Biên dịch

Chọn **XeLaTeX** trên Overleaf hoặc trình soạn thảo LaTeX. Tải nguyên thư mục này lên Overleaf, chọn `main.tex` làm tệp chính. Bản local dùng Times New Roman khi máy có phông; môi trường không có phông này tự dùng TeX Gyre Termes.

Chạy tại thư mục `latex`:

```powershell
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

Hoặc, nếu có Tectonic:

```powershell
tectonic main.tex
```

Không cần BibTeX/Biber; danh mục tham khảo hiện dùng `thebibliography`. Mọi tệp nguồn lưu UTF-8. PDF đang là bản xem Chương 1 kèm tài liệu tham khảo, chưa phải quyển tiểu luận đủ bốn chương.

## Viết tiếp

Tạo `chuong/chuong2.tex`, `chuong/chuong3.tex`, `chuong/chuong4.tex` và thêm các lệnh `\input{chuong/chuong2}`... trong `main.tex`, trước `\input{tailieu-thamkhao}`. Cấu trúc chung, số chương, số mục và số bảng sẽ nối tiếp tự động.

Thiết lập hiện tại: A4, chữ thân bài 13 pt, giãn dòng 1,25, lề trái 3 cm/phải 2 cm/trên dưới 2,5 cm. Đây là thiết lập trình bày ban đầu; có thể điều chỉnh theo mẫu chính thức của môn học.
